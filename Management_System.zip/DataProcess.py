import random
import torch
import numpy as np
import pandas as pd


def squared_loss(y_hat, y):  # @save
    """均方损失"""
    return (y_hat - y.reshape(y_hat.shape)) ** 2 / 2


def data_iter(batch_size, features, labels):
    num_examples = len(features)
    indices = list(range(num_examples))
    # 这些样本是随机读取的，没有特定的顺序
    random.shuffle(indices)
    for i in range(0, num_examples, batch_size):
        batch_indices = torch.tensor(
            indices[i: min(i + batch_size, num_examples)])
        yield features[batch_indices], labels[batch_indices]


def linreg(x, w, b):  # @save
    """线性回归模型"""
    return torch.matmul(x, w) + b


def sgd(params, lr, batch_size):  # @save
    """小批量随机梯度下降"""
    with torch.no_grad():
        for param in params:
            param -= lr * param.grad / batch_size
            param.grad.zero_()


class DataPredict:
    def __init__(self):
        self.__w = None
        self.__n = None
        self.__people_range = []
        self.res = 0

    def set_people_range(self, x, y):
        self.__people_range.clear()
        self.__people_range.append(x)
        self.__people_range.append(y)

    def predict(self):
        true_data = torch.tensor(self.__people_range)
        y = torch.matmul(true_data.float(), self.__w) + self.__n
        res = y.detach().tolist()
        return res[0]

    def train(self):
        features_df = pd.read_csv('features.csv')
        labels_df = pd.read_csv('labels.csv')
        features_array = np.array(features_df)
        labels_array = np.array(labels_df)

        # important
        features = torch.tensor(features_array, dtype=torch.float32)
        labels = torch.tensor(labels_array, dtype=torch.float32)

        # true_w = torch.tensor([0.5, -0.25])
        # true_b = 0.02

        # features, labels = synthetic_data(true_w, true_b, 1000)

        print('features:', features[0], '\nlabel:', labels[0])

        G_batch_size = 10

        for X, y in data_iter(G_batch_size, features, labels):
            print(X, '\n', y)
            break

        w = torch.normal(0, 0.01, size=(2, 1), requires_grad=True)
        b = torch.zeros(1, requires_grad=True)

        lr = 0.03
        num_epochs = 3
        net = linreg
        loss = squared_loss

        for epoch in range(num_epochs):
            for X, y in data_iter(G_batch_size, features, labels):
                l = loss(net(X, w, b), y)  # X和y的小批量损失
                # 因为l形状是(batch_size,1)，而不是一个标量。l中的所有元素被加到一起，
                # 并以此计算关于[w,b]的梯度
                l.sum().backward()
                sgd([w, b], lr, G_batch_size)  # 使用参数的梯度更新参数
            with torch.no_grad():
                train_l = loss(net(features, w, b), labels)
                print(f'epoch {epoch + 1}, loss {float(train_l.mean()):f}')

            # self.__n.clear()
            # self.__w.clear()

            # for i in w.detach().numpy().tolist():
            #    self.__w.append(i)
            # for b in b.detach().numpy().tolist():
            #    self.__n.append(b)

            # print(f'w的估计值: {w}')
            # print(f'b的估计值: {b}')

            self.__w = w
            self.__n = b
            print(w, b)


if __name__ == '__main__':
    pre = DataPredict()
    pre.set_people_range(10.2, 20)
    pre.train()
    print(pre.predict())
